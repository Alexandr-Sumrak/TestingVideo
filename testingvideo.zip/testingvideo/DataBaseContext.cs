﻿namespace linq_1
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class DataBaseContext : DbContext
    {

        public DataBaseContext()
            : base("name=DataBaseContext")
        {
        }


        public DbSet<People> Peoples {get;set;}
    }

}